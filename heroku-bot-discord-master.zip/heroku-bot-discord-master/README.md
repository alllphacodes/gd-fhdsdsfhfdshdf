# heroku-bot-discord
Archivos para la activación de un bot discord en heroku app de la guía [MyBOT Heroku](https://portalmybot.com/guia/heroku/)
